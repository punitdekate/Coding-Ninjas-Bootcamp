import styles from "./loader.module.css";
function Loader() {
  return (
    <>
      <span className={styles.loader}></span>
    </>
  );
}
export default Loader;
